let timer;
let running = false;
let startTime;
let elapsedTime = 0;

function startStop() {
  if (running) {
    clearInterval(timer);
    running = false;
    document.getElementById('startStop').innerText = 'Start';
  } else {
    startTime = Date.now() - elapsedTime;
    timer = setInterval(updateDisplay, 10);
    running = true;
    document.getElementById('startStop').innerText = 'Stop';
  }
}

function reset() {
  clearInterval(timer);
  running = false;
  elapsedTime = 0;
  document.getElementById('display').innerText = '00:00:00';
  document.getElementById('startStop').innerText = 'Start';
  document.getElementById('laps').innerHTML = '';
}

function lap() {
  if (running) {
    const lapTime = Date.now() - startTime;
    const formattedLapTime = formatTime(lapTime);
    const lapItem = document.createElement('li');
    lapItem.innerText = formattedLapTime;
    document.getElementById('laps').appendChild(lapItem);
  }
}

function updateDisplay() {
  const currentTime = Date.now();
  elapsedTime = currentTime - startTime;
  const formattedTime = formatTime(elapsedTime);
  document.getElementById('display').innerText = formattedTime;
}

function formatTime(time) {
  const ms = time % 1000;
  const seconds = Math.floor((time / 1000) % 60);
  const minutes = Math.floor((time / (1000 * 60)) % 60);
  const hours = Math.floor((time / (1000 * 60 * 60)) % 24);
  return (
    (hours < 10 ? '0' : '') + hours + ':' +
    (minutes < 10 ? '0' : '') + minutes + ':' +
    (seconds < 10 ? '0' : '') + seconds
  );
}
